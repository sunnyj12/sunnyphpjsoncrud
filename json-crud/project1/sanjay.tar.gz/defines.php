<?php
/**
 * @package    Joomla.Site
 *
 * @copyright  Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

// Global definitions
$parts = explode(DIRECTORY_SEPARATOR, JPATH_BASE);

// Defines.
define('JPATH_ROOT',          implode(DIRECTORY_SEPARATOR, $parts));
define('JPATH_SITE',          JPATH_ROOT);
define('JPATH_CONFIGURATION', JPATH_ROOT);
define('JPATH_ADMINISTRATOR', JPATH_ROOT . DIRECTORY_SEPARATOR . 'administrator');
define('JPATH_LIBRARIES',     JPATH_ROOT . DIRECTORY_SEPARATOR . 'libraries');
define('JPATH_PLUGINS',       JPATH_ROOT . DIRECTORY_SEPARATOR . 'plugins');
define('JPATH_INSTALLATION',  JPATH_ROOT . DIRECTORY_SEPARATOR . 'installation');
define('JPATH_THEMES',        JPATH_BASE . DIRECTORY_SEPARATOR . 'templates');
define('JPATH_CACHE',         JPATH_BASE . DIRECTORY_SEPARATOR . 'cache');
define('JPATH_MANIFESTS',     JPATH_ADMINISTRATOR . DIRECTORY_SEPARATOR . 'manifests');

define('JPATH_BUILDERS', 'https://builders-staging.onsumaye.com/');
define('JPATH_NETWORKBUILDERS', 'https://networkbuilders-staging.onsumaye.com/');
#Absolute Path 
#Added By Piush Gupta
define('JPATH_BUILDERS_ABS', '/var/www/html/builders-staging.onsumaye.com/public_html/');
define('JPATH_NETWORKBUILDERS_ABS', '/var/www/html/networkbuilders-staging.onsumaye.com/');

//AWS url
define('JPATH_AWS_NETWORKBUILDERS_CDN', 'https://s3.us-east-2.amazonaws.com/networkbuilders-cdn');
define('JPATH_AWS_DATACENTER', 'https://s3.us-east-2.amazonaws.com/builders-datacenter');
define('JPATH_AWS_BUILDERS', 'https://s3.us-east-2.amazonaws.com/intel-builders');
define('JPATH_AWS_UNIVERSITY_VIDEO_CDN', 'https://s3.us-east-2.amazonaws.com/university-video-cdn');
define('JPATH_AWS_INB_CDN', 'https://s3.us-east-2.amazonaws.com/inb-cdn');
define('JPATH_AWS_FABRIC', 'https://s3.us-east-2.amazonaws.com/intel-builders/fabric');
define('JPATH_AWS_CLOUD', 'https://s3.us-east-2.amazonaws.com/intel-builders/cloud');
define('JPATH_AWS_ICB', 'https://s3.us-east-2.amazonaws.com/intel-builders/icb');
define('JPATH_AWS_STORAGE', 'https://s3.us-east-2.amazonaws.com/intel-builders/storage');
define('JPATH_AWS_BUILDERS_INTEL_FONTS', 'https://s3.us-east-2.amazonaws.com/intel-builders/intel-fonts');

define('EUROPEA_PRIVACY_POLICY_TEXT', 'By submitting this form, you are confirming you are an adult 18 years or older and you agree to share your personal information with Intel. You can unsubscribe at any time. Intel’s websites and communications are subject to our <a onclick="ga(\'\send\', \'\event\', \'Hits on External Links\', \'Link: www.intel.com/privacy\', \'http://www.intel.com/privacy\');" href="http://www.intel.com/privacy" target="_blank">Privacy Notice</a> and <a onclick="ga(\'\send\', \'\event\', \'Hits on External Links\', \'Link: www.intel.com/content/www/us/en/legal/terms-of-use.html\', \'https://www.intel.com/content/www/us/en/legal/terms-of-use.html\');" href="https://www.intel.com/content/www/us/en/legal/terms-of-use.html" target="_blank">Terms of Use</a>.'); 
 
define('NON_EUROPEA_PRIVACY_POLICY_TEXT', 'By submitting this form, you are confirming you are an adult 18 years or older and you agree to share your personal information with Intel to use for this business request. You also agree to subscribe to stay connected to the latest Intel technologies and industry trends by email and telephone. You may unsubscribe at any time. Intel’s websites and communications are subject to our <a onclick="ga(\'\send\', \'\event\', \'Hits on External Links\', \'Link: www.intel.com/privacy\', \'http://www.intel.com/privacy\');" href="http://www.intel.com/privacy" target="_blank">Privacy Notice</a> and <a onclick="ga(\'\send\', \'\event\', \'Hits on External Links\', \'Link: www.intel.com/content/www/us/en/legal/terms-of-use.html\', \'https://www.intel.com/content/www/us/en/legal/terms-of-use.html\');" href="https://www.intel.com/content/www/us/en/legal/terms-of-use.html" target="_blank">Terms of Use</a>.'); 
 
define('EUROPEA_PRIVACY_POLICY_SEC_SIGN_UP_TEXT', 'By submitting this form, you are confirming you are an adult 18 years or older and you agree to share your personal information with Intel. You can unsubscribe at any time. Intel’s websites and communications are subject to our <a onclick="ga(\'\send\', \'\event\', \'Hits on External Links\', \'Link: www.intel.com/privacy\', \'http://www.intel.com/privacy\');" href="http://www.intel.com/privacy" target="_blank">Privacy Notice</a> and <a onclick="ga(\'\send\', \'\event\', \'Hits on External Links\', \'Link: www.intel.com/content/www/us/en/legal/terms-of-use.html\', \'https://www.intel.com/content/www/us/en/legal/terms-of-use.html\');" href="https://www.intel.com/content/www/us/en/legal/terms-of-use.html" target="_blank">Terms of Use</a>.'); 
 
define('NON_EUROPEA_PRIVACY_POLICY_SEC_SIGN_UP_TEXT', 'By submitting this form, you are confirming you are an adult 18 years or older and you agree to share your personal information with Intel to use for this business request. You also agree to subscribe to stay connected to the latest Intel technologies and industry trends by email and telephone. You may unsubscribe at any time. Intel’s websites and communications are subject to our <a onclick="ga(\'\send\', \'\event\', \'Hits on External Links\', \'Link: www.intel.com/privacy\', \'http://www.intel.com/privacy\');" href="http://www.intel.com/privacy" target="_blank">Privacy Notice</a> and <a onclick="ga(\'\send\', \'\event\', \'Hits on External Links\', \'Link: www.intel.com/content/www/us/en/legal/terms-of-use.html\', \'https://www.intel.com/content/www/us/en/legal/terms-of-use.html\');" href="https://www.intel.com/content/www/us/en/legal/terms-of-use.html" target="_blank">Terms of Use</a>.'); 
 
define('REGISTER_PRIVACY_COMMON_TEXT', '<p>If you enroll in any of the Intel® Builders University course, your name, email address, course title, and course registration date will be provided to your employer.</p><p>You agree that Intel Corporation ("Intel") may, but is not obligated to, use, on a royalty-free basis, your company name and logo on the Intel® Builders website and in Intel® Builders programs such as, without limitation, in webinars, collateral (solution blueprints, solution briefs, case studies, proof of concepts), events, and other Intel® Builders\' programming to promote your company and the program. Additionally, you agree that Intel may, but is not obligated to, use, on a royalty-free basis, your company name and logo at public events to demonstrate your participation in the Intel® Builders program. By clicking "Submit" you are warranting that you are officially authorized to provide your company\'s logo for use in the Intel® Builders program as described in these terms. Your personal information will only be used by program administrators to communicate with you directly about the program.</p>');

define('NON_EVENT_EUROPEA_PRIVACY_POLICY_TEXT', 'By submitting this form, you are confirming you are an adult 18 years or older and you agree to share your personal information with Intel to use for this business request. You also agree to subscribe to stay connected to the latest Intel technologies and industry trends by email and telephone. You may unsubscribe at any time. Intel’s websites and communications are subject to our <a onclick="ga(\'\send\', \'\event\', \'Hits on External Links\', \'Link: www.intel.com/privacy\', \'http://www.intel.com/privacy\');" href="http://www.intel.com/privacy" target="_blank">Privacy Notice</a> and <a onclick="ga(\'\send\', \'\event\', \'Hits on External Links\', \'Link: www.intel.com/content/www/us/en/legal/terms-of-use.html\', \'https://www.intel.com/content/www/us/en/legal/terms-of-use.html\');" href="https://www.intel.com/content/www/us/en/legal/terms-of-use.html" target="_blank">Terms of Use</a>.');

define('EVENT_EUROPEA_PRIVACY_POLICY_TEXT', 'By submitting this form, you are confirming you are an adult 18 years or older and you agree to share your personal information with Intel to use for this business request. Intel’s websites and communications
are subject to our <a onclick="ga(\'\send\', \'\event\', \'Hits on External Links\', \'Link: www.intel.com/privacy\', \'http://www.intel.com/privacy\');" href="http://www.intel.com/privacy" target="_blank">Privacy Notice</a> and <a onclick="ga(\'\send\', \'\event\', \'Hits on External Links\', \'Link: www.intel.com/content/www/us/en/legal/terms-of-use.html\', \'https://www.intel.com/content/www/us/en/legal/terms-of-use.html\');" href="https://www.intel.com/content/www/us/en/legal/terms-of-use.html" target="_blank">Terms of Use</a>.');

define('EUROPEAN_JOIN_PROGRAM_TEXT', '<strong>Yes</strong>, I would like to subscribe to stay connected to the latest Intel technologies and industry trends by email and telephone. You can unsubscribe at any time.');
/*******Database connection start***************/
/*
 * @Author Kapil Dev Sharma <kapildev.sharma@onsumauye.com>
 * Created On <25-02-2017> 
 */

#IB
#For IB
define('IBhost','10.0.1.23');
define('IBuser','builders_staging');
define('IBpassword','GTy^%&*IUY67Y');
define('IBdatabase','builders_staging');

#For INB
define('INBhost','10.0.1.208');
define('INBuser','newinb');
define('INBpassword','I!1N_b11_Nn');
define('INBdatabase','new_inb');
#For IB
#define('IBhost','18.219.199.219');
#define('IBuser','builders_qa');
#define('IBpassword','G%yTuGH^657KL');
#define('IBdatabase','builders_qa');


#For INB
#define('INBhost','18.220.53.45');
#define('INBuser','inb_qa');
#define('INBpassword','AFg%$6tYU67UJ');
#define('INBdatabase','inb_qa');

//Country API Access Key
#define('COUNTRY_API_ACCESS_KEY', '0b204dd43578f026e69d6e7f491d2270');
define('COUNTRY_API_ACCESS_KEY', '380a36b1a451a92c7ea911edcff4054f');
/*******Database connection End***************/
#For Mailer DB
      define('MailerHost','10.178.6.195');
      define('MailerUser','mailer_user');
      define('MailerPassword','jh&^898IUg5T');
      define('MailerDatabase','mailer_db');
